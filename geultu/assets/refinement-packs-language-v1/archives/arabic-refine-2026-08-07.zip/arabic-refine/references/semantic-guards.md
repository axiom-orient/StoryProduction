# Semantic-preservation guards — العربية

Do not replace the protected Arabic expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `قد يفشل الطلب.` | `سيفشل الطلب.` | الاحتمال واليقين |
| `إذا فُعّلت الميزة` | `عندما فُعّلت الميزة` | الشرط والحدث المفترض وقوعه |
| `حاول الوكيل نشر الإصدار.` | `نشر الوكيل الإصدار.` | المحاولة والإنجاز |
| `لم يتمكن من تأكيد السبب.` | `أكد السبب.` | النفي |
| `بعض الطلبات` | `جميع الطلبات` | نطاق الكمية |
| `ما زالت الخدمة تعمل منذ الاثنين.` | `عملت الخدمة يوم الاثنين.` | الاستمرار والحدث المكتمل |
| `صُممت الحماية لمنع الحذف.` | `لم يحدث الحذف.` | قصد التصميم والنتيجة المرصودة |
| `لذلك استؤنفت المعالجة.` | `بعد ذلك استؤنفت المعالجة.` | السببية والترتيب الزمني |
| `هذه القيمة تساوي 12.` | `هذا السعر يساوي 12.` | نوع المرجع |
| `يبدو أن زمن الاستجابة يزداد.` | `يزداد زمن الاستجابة.` | التحفظ المعرفي والتقرير |
| `ينبغي الاحتفاظ بالسجل.` | `يجب الاحتفاظ بالسجل.` | التوصية والإلزام |
| `يمكن للمحوّل بث النتائج.` | `يبث المحوّل النتائج.` | القدرة والسلوك الفعلي |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
