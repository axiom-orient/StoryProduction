# French Refine

`french-refine`는 **Français 전용 독립 스킬**입니다. 이미 Français로 작성된 글을 최소 수정하고, 문맥에 맞는 단어·구·문장 후보를 선택하거나 표시된 표현을 치환합니다.

## 기능

| 모드 | 입력 | 기본 출력 |
|---|---|---|
| `polish` | Français 본문 | 다듬은 본문만 |
| `choose` | 문맥 + Français 후보 2개 이상 | 선택한 표현 + 최대 2문장 근거 |
| `replace` | 문맥 + 치환 대상 | 치환된 본문만 |

## 불변식

- 의미·사실·부정·조건·범위·가능성·의무·시제·상을 문체보다 먼저 보존합니다.
- 지역 변이와 격식은 `fr`를 무조건 강제하지 않고 원문·사용자 계약을 따릅니다.
- 사용자 용어집과 하우스 스타일이 일반 언어 지침보다 우선합니다.
- 번역·요약·확장·사실 검증·말투 변환은 하지 않습니다.
- 안전한 개선이 없으면 원문을 반환합니다.
- AI 작성 여부를 판정하지 않습니다.

## 사용 예

```text
$french-refine : révisez ce texte français ou choisissez la formulation la plus adaptée au contexte.
```

ChatGPT에서는 스킬 선택기에서 `@`로 명시 호출하고, Codex CLI·IDE에서는 `/skills` 또는 `$french-refine`를 사용합니다. `agents/openai.yaml`의 기본 프롬프트도 `$french-refine`를 사용합니다.

## 구성

- `SKILL.md`: 실행 계약과 절차
- `references/semantic-guards.md`: 의미 회귀 금지 쌍
- `references/language-guidance.md`: 언어별 문법·표기·변이·어휘 선택 지침
- `references/source-policy.md`: 근거 우선순위와 권위 자료
- `tests/eval_cases.json`: 트리거, 의미 보존, 후보 선택, 변이, 보호 문자열 사례
- `tests/test_skill_contract.py`: 정적 계약 테스트
- `tests/MODEL_EVAL_GUIDE.md`: 실제 모델 실행 평가 절차

## 검증 범위

정적 테스트는 파일 구조, 경계 응답, 계약 문구, 사례 수와 스키마를 검증합니다. 실제 모델의 언어 품질이나 모든 문맥에서의 의미 보존을 증명하지 않습니다. 실제 배포 전에는 원어민 독립 평가와 회귀 실행이 필요합니다.
