# Semantic-preservation guards — Français

Do not replace the protected French expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `La requête peut échouer.` | `La requête échouera.` | possibilité et certitude |
| `Si la fonction est activée` | `Quand la fonction est activée` | condition et événement présupposé |
| `Il a tenté de déployer la version.` | `Il a déployé la version.` | tentative et achèvement |
| `Il n’a pas pu confirmer la cause.` | `Il a confirmé la cause.` | négation |
| `Certaines requêtes` | `Toutes les requêtes` | portée du quantificateur |
| `Le service fonctionne depuis lundi.` | `Le service a fonctionné lundi.` | continuité et événement achevé |
| `Le garde-fou a été conçu pour empêcher la suppression.` | `La suppression n’a pas eu lieu.` | intention de conception et résultat observé |
| `Le traitement a donc repris.` | `Le traitement a ensuite repris.` | causalité et succession temporelle |
| `Cette valeur est 12.` | `Ce prix est 12.` | type du référent |
| `La latence semble augmenter.` | `La latence augmente.` | prudence épistémique et assertion |
| `Vous devriez conserver le journal.` | `Vous devez conserver le journal.` | recommandation et obligation |
| `L’adaptateur peut diffuser les résultats.` | `L’adaptateur diffuse les résultats.` | capacité et comportement effectif |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
