# Français language guidance

## Variant contract

Conservez la variété attestée — France, Canada, Belgique, Suisse ou autre — ainsi que le vouvoiement/tutoiement, le lexique et la typographie. Utilisez le français de France uniquement en l’absence de tout indice ou besoin régional.

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. Vérifiez accords, genre, nombre, régime prépositionnel, antécédents pronominaux, temps et mode dans le contexte.
2. Préservez le contraste entre indicatif, subjonctif, conditionnel et infinitif lorsqu’il encode réalité, doute, souhait, hypothèse ou discours rapporté.
3. Ne supprimez pas automatiquement le ‘ne’ : sa présence dépend du registre, de la syntaxe et de la voix de l’auteur.
4. La voix passive et les tournures impersonnelles structurent l’information; ne les remplacez que si l’agent et le foyer restent identiques.
5. Réduisez les nominalisations administratives seulement lorsqu’un verbe direct conserve la précision juridique ou technique.
6. Préservez les relations causales, conditionnelles, concessives, temporelles et additives des connecteurs.
7. Respectez les espaces insécables, guillemets, signes doubles et conventions typographiques de la variété et du support.
8. Évaluez les anglicismes selon l’usage, le domaine et la région; ne les remplacez pas de manière systématique.
9. Le glossaire utilisateur, la terminologie réglementaire et les noms d’interface priment sur les préférences générales.
10. Gardez un terme stable pour un concept stable; évitez la rotation de synonymes décorative.
11. Préservez la voix littéraire, les fragments, les répétitions intentionnelles et l’oralité des dialogues.
12. Ne prétendez pas détecter une origine IA; traitez seulement les formules vides, l’emphase sans fonction et les répétitions mécaniques observables.

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `Cliquez sur Enregistrer pour sauvegarder le courriel.` | `Cliquez sur Sauvegarder pour enregistrer l’e-mail.` | Conserver le lexique canadien ou organisationnel s’il est cohérent. |
| `Tu peux vérifier le dossier demain.` | `Vous pouvez vérifier le dossier demain.` | Ne pas changer le tutoiement en vouvoiement sans demande. |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| Atteindre le résultat attendu | `efficient` / `efficace` | `efficace` | ‘Efficace’ est l’usage standard pour l’atteinte d’un objectif; ‘efficient’ est spécialisé. |
| Porter un objet jusqu’ici | `amener le dossier` / `apporter le dossier` | `apporter le dossier` | ‘Apporter’ convient à une chose; ‘amener’ s’emploie d’abord pour un être animé. |
| Instruction simple pour une action | `procéder à la vérification` / `vérifier` | `vérifier` | Le verbe direct est plus clair sans perte de registre. |
| Demande administrative formelle | `demander les pièces` / `solliciter les pièces` | `demander les pièces` | Le verbe courant reste précis; ‘solliciter’ peut être inutilement administratif selon la phrase. |
| Résultat informatique conservé sur disque | `sauver le fichier` / `enregistrer le fichier` | `enregistrer le fichier` | C’est le terme général en français de France, sauf terminologie d’interface différente. |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
