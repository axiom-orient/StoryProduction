# Semantic-preservation guards — Español

Do not replace the protected Spanish expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `La solicitud puede fallar.` | `La solicitud fallará.` | posibilidad frente a certeza |
| `Si se activa la función` | `Cuando se activa la función` | condición frente a evento asumido |
| `Intentó desplegar la versión.` | `Desplegó la versión.` | intento frente a finalización |
| `No pudo confirmar la causa.` | `Confirmó la causa.` | negación |
| `Algunas solicitudes` | `Todas las solicitudes` | alcance cuantificador |
| `Lleva funcionando desde el lunes.` | `Funcionó el lunes.` | aspecto continuativo frente a evento acabado |
| `Se diseñó para evitar el borrado.` | `El borrado no ocurrió.` | intención de diseño frente a resultado observado |
| `Por eso se reanudó el proceso.` | `Después se reanudó el proceso.` | causalidad frente a orden temporal |
| `Este valor es 12.` | `Este precio es 12.` | tipo de referente |
| `La latencia parece aumentar.` | `La latencia aumenta.` | cautela epistémica frente a afirmación |
| `Debería conservar el registro.` | `Debe conservar el registro.` | recomendación frente a obligación |
| `El adaptador puede transmitir resultados.` | `El adaptador transmite resultados.` | capacidad frente a conducta efectiva |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
