# Español language guidance

## Variant contract

Conserva la variedad documentada (España, México, Argentina, Colombia u otra), incluido el tratamiento tú/usted/vos, el léxico y las convenciones. Solo usa un español internacional neutro cuando no haya señales regionales ni requisitos del usuario.

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. Comprueba concordancia, régimen preposicional, referentes pronominales, tiempos, aspecto y modo verbal en contexto.
2. Conserva indicativo, subjuntivo y condicional cuando codifican realidad, hipótesis, deseo, valoración o distancia epistémica.
3. No conviertas tú, usted, ustedes o vos ni sus formas verbales sin una instrucción explícita.
4. Revisa queísmo y dequeísmo según el régimen real del verbo o sustantivo, no mediante sustituciones mecánicas.
5. Los clíticos, se y las construcciones pasivas o impersonales pueden cambiar agente y foco; edítalos con cautela.
6. No uses el infinitivo, el gerundio ni la voz activa como solución universal; protege simultaneidad, anterioridad y resultado.
7. Elimina nominalizaciones burocráticas solo cuando un verbo directo conserve precisión y registro.
8. Mantén la relación lógica de conectores causales, condicionales, concesivos, temporales y aditivos.
9. Respeta terminología jurídica, técnica y regional, además del glosario del usuario.
10. No sustituyas términos repetidos solo por variedad estilística si nombran el mismo concepto técnico.
11. Aplica puntuación y mayúsculas panhispánicas sin borrar convenciones editoriales justificadas.
12. No atribuyas autoría de IA; trata solo patrones observables como muletillas, énfasis vacío y repetición mecánica.

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `Vos podés guardar el archivo acá.` | `Tú puedes guardar el fichero aquí.` | No eliminar el voseo ni cambiar la variedad rioplatense. |
| `Pulse «Aceptar» para guardar el fichero.` | `Haz clic en “Aceptar” para guardar el archivo.` | Conservar español de España y tratamiento formal si son consistentes. |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| Lograr el objetivo, sin hablar del uso de recursos | `eficiente` / `eficaz` | `eficaz` | ‘Eficaz’ describe que alcanza el efecto previsto. |
| Anticipar un hecho futuro | `prever` / `prevenir` | `prever` | ‘Prever’ es anticipar; ‘prevenir’ es evitar o advertir. |
| Instrucción general y directa | `realizar una comprobación` / `comprobar` | `comprobar` | El verbo directo es preciso y menos burocrático. |
| Pedir formalmente documentación | `solicitar` / `pedir` | `solicitar` | El contexto administrativo requiere un registro formal. |
| Una causa neutral | `debido a` / `a causa de` | `debido a` | La alternativa evita una connotación negativa no presente en el contexto. |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
