# Origin record

| Field | Value |
|---|---|
| Derived skill | `italian-refine` |
| Target language | Italiano (`it-IT`) |
| Source archive | `koreanize(10).zip` |
| Source SHA-256 | `f27d5c8788611deaa63dc5b1b029b5892db8feefe7ea7700c3d33b6a530bd0d8` |
| Derivation date | 2026-08-07 |
| Source contract tests | 19/19 passed before derivation |

The upstream source files required by the Attribution License are stored in `upstream/koreanize/`. This record is provenance, not a quality certificate.
