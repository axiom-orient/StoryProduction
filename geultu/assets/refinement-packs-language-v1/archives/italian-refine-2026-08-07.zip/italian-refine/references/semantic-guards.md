# Semantic-preservation guards — Italiano

Do not replace the protected Italian expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `La richiesta può fallire.` | `La richiesta fallirà.` | possibilità e certezza |
| `Se la funzione viene attivata` | `Quando la funzione viene attivata` | condizione ed evento presupposto |
| `Ha tentato di distribuire la versione.` | `Ha distribuito la versione.` | tentativo e completamento |
| `Non ha potuto confermare la causa.` | `Ha confermato la causa.` | negazione |
| `Alcune richieste` | `Tutte le richieste` | portata del quantificatore |
| `Il servizio funziona da lunedì.` | `Il servizio ha funzionato lunedì.` | continuità ed evento concluso |
| `La protezione è stata progettata per impedire la cancellazione.` | `La cancellazione non è avvenuta.` | intento progettuale e risultato osservato |
| `Perciò l’elaborazione è ripresa.` | `Poi l’elaborazione è ripresa.` | causalità e successione temporale |
| `Questo valore è 12.` | `Questo prezzo è 12.` | tipo di referente |
| `La latenza sembra aumentare.` | `La latenza aumenta.` | cautela epistemica e affermazione |
| `Dovresti conservare il registro.` | `Devi conservare il registro.` | raccomandazione e obbligo |
| `L’adattatore può trasmettere i risultati.` | `L’adattatore trasmette i risultati.` | capacità e comportamento effettivo |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
