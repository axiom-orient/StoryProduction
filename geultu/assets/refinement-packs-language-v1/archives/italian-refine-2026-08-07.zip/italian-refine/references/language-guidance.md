# Italiano language guidance

## Variant contract

Mantieni la varietà, il registro, il tu/Lei/voi, la terminologia regionale o aziendale e le convenzioni editoriali documentate. Usa l’italiano standard contemporaneo solo quando non emergono altre indicazioni.

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. Controlla concordanza, genere, numero, reggenza, clitici, riferimenti, tempi e modi nel contesto.
2. Preserva indicativo, congiuntivo, condizionale e infinito quando esprimono realtà, dubbio, desiderio, ipotesi o discorso indiretto.
3. Rispetta la consecutio temporum; una frase più breve non deve spostare anteriorità, contemporaneità o posteriorità.
4. La posizione dei clitici e le preposizioni articolate non vanno corrette con regole isolate dal verbo e dal registro.
5. Voce passiva, si impersonale e soggetto sottinteso cambiano fuoco informativo e responsabilità.
6. Riduci nominalizzazioni burocratiche solo se un verbo diretto conserva precisione e formalità.
7. Non imporre il congiuntivo o l’indicativo come preferenza assoluta: valuta significato, registro e costruzione.
8. Mantieni i rapporti causali, condizionali, concessivi, temporali e additivi dei connettivi.
9. Glossario dell’utente, terminologia giuridica, tecnica e nomi dell’interfaccia hanno priorità.
10. Usa un termine stabile per un concetto stabile; evita sinonimi ornamentali.
11. Punteggiatura e maiuscole richiedono spesso giudizio contestuale, non una regola binaria.
12. Non dichiarare di rilevare un’autoria IA; tratta solo formule vuote, enfasi senza funzione e ripetizioni meccaniche osservabili.

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `La prego di verificare il documento.` | `Controlla il documento.` | Non cambiare dal Lei formale al tu. |
| `Mo’ vediamo che succede.` | `Ora vediamo che cosa accade.` | Non neutralizzare una voce regionale o narrativa intenzionale. |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| La soluzione raggiunge l’obiettivo | `efficiente` / `efficace` | `efficace` | ‘Efficace’ riguarda il risultato; ‘efficiente’ il rapporto con le risorse. |
| Azione semplice in un’istruzione | `effettuare una verifica` / `verificare` | `verificare` | Il verbo diretto è più chiaro senza perdita di precisione. |
| Mettere in pratica una politica | `implementare la politica` / `attuare la politica` | `attuare la politica` | ‘Attuare’ è più preciso per una politica; ‘implementare’ è comune in ambito tecnico. |
| Domanda formale di documenti | `chiedere i documenti` / `richiedere i documenti` | `richiedere i documenti` | Il contesto amministrativo giustifica il registro formale. |
| Conservare dati in memoria non volatile | `salvare i dati` / `memorizzare i dati` | `salvare i dati` | È il verbo generale dell’interfaccia; ‘memorizzare’ può indicare il meccanismo tecnico. |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
