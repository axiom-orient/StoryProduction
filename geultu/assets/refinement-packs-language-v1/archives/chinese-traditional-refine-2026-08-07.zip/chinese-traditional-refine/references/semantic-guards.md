# Semantic-preservation guards — 繁體中文

Do not replace the protected Traditional Chinese expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `請求可能失敗` | `請求必然失敗` | 可能性與確定性 |
| `如果啟用此功能` | `當此功能已啟用時` | 條件與已發生事件 |
| `嘗試部署版本` | `已部署版本` | 嘗試與完成 |
| `未能確認原因` | `確認了原因` | 否定與肯定 |
| `部分請求` | `全部請求` | 數量範圍 |
| `自週一持續運作` | `週一運作過` | 持續狀態與已完成事件 |
| `為避免刪除而設計` | `刪除剛好沒有發生` | 設計意圖與觀察結果 |
| `因此處理恢復` | `隨後處理恢復` | 因果與時間順序 |
| `這個數值` | `這筆金額` | 指涉對象類型 |
| `延遲似乎增加` | `延遲增加` | 推測與斷言 |
| `應保留紀錄` | `必須保留紀錄` | 規範強度 |
| `介接器可以串流回傳結果` | `介接器正在串流回傳結果` | 能力與實際行為 |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
