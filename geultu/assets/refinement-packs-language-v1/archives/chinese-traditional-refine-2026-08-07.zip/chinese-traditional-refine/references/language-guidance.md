# 繁體中文 language guidance

## Variant contract

預設採臺灣繁體中文（zh-TW）。若原文明確採香港或澳門用詞、字形與標點慣例，則完整保留；不得擅自轉換為中國大陸簡體詞彙。

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. 依上下文檢查主謂搭配、修飾關係、指涉、數量範圍、語序與標點。
2. 保留「了、著、過」所表達的完成、持續與經歷，不為簡短而任意刪除。
3. 保留「可能、可以、應、必須、似乎、據稱」等情態與證據強度。
4. 「把」字句與「被」字句涉及焦點與責任主體，不以主動句為唯一目標。
5. 長定語僅在修飾關係明確時拆分，避免新增歧義。
6. 「進行、予以、實現、相關、方面」僅在空泛且可安全替換時刪改。
7. 因果、條件、轉折、遞進與時間連接詞不是可一律刪除的贅詞。
8. 臺灣預設採「軟體、資料、網路、檔案」等慣用詞；香港、澳門原文則保留其既有用語。
9. 技術、法律、政策、產品術語優先遵循使用者詞彙表與權威規範。
10. 同一概念保持同一用詞，不為變化而輪換近義詞。
11. 全形標點、引號、書名號、數字與單位遵循原文地區及文書體例。
12. 不判定AI作者身分，只把可觀察的套語堆疊、空泛強調與機械重複當成編輯訊號。

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `請將檔案儲存到資料夾。` | `请将文件保存到文件夹。` | 不得轉為中國大陸簡體字形與詞彙。 |
| `閣下可於下方查閱詳情。` | `你可以在下面看詳細內容。` | 香港正式語域若有證據，不得改成臺灣口語。 |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| 依證據與標準判定結果是否成立 | `確認` / `驗證` | `驗證` | 語境要求基於標準的有效性判斷。 |
| 啟動程式或命令 | `執行` / `實施` | `執行` | 技術語境中用於運行程式或命令。 |
| 相同成果下減少資源 | `有效` / `高效` | `高效` | 強調資源投入與產出的比例。 |
| 軟體缺陷再次出現 | `重複` / `回歸` | `回歸` | 「回歸測試」是既定工程用語。 |
| 臺灣使用者介面中的 file | `文件` / `檔案` | `檔案` | 臺灣資訊語境通常以「檔案」指電腦 file。 |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
