# Português do Brasil language guidance

## Variant contract

Use o português brasileiro (pt-BR) e preserve você/tu, colocação pronominal, léxico regional, terminologia de produto e grau de formalidade já estabelecidos. Não converta para português europeu.

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. Verifique concordância, regência, crase, colocação pronominal, referência, tempos, aspecto e modo no contexto.
2. Preserve as diferenças entre pode, poderia, deve, deveria, precisa e tem de; não as trate como sinônimos de estilo.
3. Mantenha você/tu e as formas verbais correspondentes segundo a variedade e a voz do texto.
4. Revise por que, porque, por quê e porquê conforme a função real, não por substituição cega.
5. Voz passiva, indeterminação com se e sujeito oculto alteram foco e responsabilidade; edite com cautela.
6. Gerúndio não é erro por si só; preserve duração, simultaneidade e progressividade quando relevantes.
7. Reduza nominalizações burocráticas apenas quando um verbo direto mantiver precisão e formalidade.
8. Conectores de causa, condição, concessão, tempo e adição não são intercambiáveis.
9. O glossário do usuário, a terminologia legal e os nomes de interface têm precedência.
10. Mantenha um termo por conceito e evite variar sinônimos apenas por elegância.
11. Siga a ortografia vigente e o padrão tipográfico do documento, incluindo números, unidades e citações.
12. Não alegue detectar autoria de IA; trate apenas clichês, ênfase vazia e repetição mecânica observável.

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `O usuário deve salvar o arquivo nesta pasta.` | `O utilizador deve guardar o ficheiro nesta pasta.` | Não converter léxico brasileiro para português europeu. |
| `Tu podes verificar isso amanhã.` | `Você pode verificar isso amanhã.` | Preservar o sistema de tratamento regional consistente. |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| A solução atinge o objetivo | `eficiente` / `eficaz` | `eficaz` | ‘Eficaz’ descreve alcance do resultado; ‘eficiente’ trata de recursos. |
| Arquivo digital em interface brasileira | `ficheiro` / `arquivo` | `arquivo` | É o termo padrão no português brasileiro de tecnologia. |
| Pessoa que usa um sistema | `utilizador` / `usuário` | `usuário` | É a forma corrente no Brasil, salvo terminologia institucional diferente. |
| Ação simples em instrução | `realizar a verificação` / `verificar` | `verificar` | O verbo direto é mais claro sem perda de precisão. |
| Guardar alterações em software | `salvar` / `guardar` | `salvar` | É a opção comum em interfaces brasileiras; preserve o rótulo real do produto. |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
