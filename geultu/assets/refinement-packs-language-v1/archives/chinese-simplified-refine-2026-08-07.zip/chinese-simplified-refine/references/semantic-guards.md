# Semantic-preservation guards — 简体中文

Do not replace the protected Simplified Chinese expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `请求可能失败` | `请求必然失败` | 可能性与确定性 |
| `如果启用该功能` | `当该功能已启用时` | 条件与已发生事件 |
| `尝试部署构建` | `已经部署构建` | 尝试与完成 |
| `未能确认原因` | `确认了原因` | 否定与肯定 |
| `部分请求` | `全部请求` | 数量范围 |
| `从周一一直在运行` | `周一运行过` | 持续体与已完成事件 |
| `为避免删除而设计` | `删除碰巧没有发生` | 设计意图与观察结果 |
| `因此处理恢复` | `随后处理恢复` | 因果关系与时间顺序 |
| `这个数值` | `这笔金额` | 指代对象的类型 |
| `延迟似乎增加` | `延迟增加` | 推测与断言 |
| `应当保留日志` | `必须保留日志` | 建议或规范性要求的强度 |
| `适配器可以流式返回结果` | `适配器正在流式返回结果` | 能力与实际行为 |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
