# 简体中文 language guidance

## Variant contract

默认采用中国大陆规范简体中文（zh-CN）。如原文明确采用新加坡、马来西亚或机构专用术语，则保留该变体；不得擅自转换为繁体或台湾、香港用词。

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. 结合上下文检查主谓搭配、定中关系、指代、数量范围、语序和标点。
2. 区分‘的、地、得’，但不得用机械规则改坏固定术语、引用或人物口吻。
3. 保留‘了、着、过’所表达的完成、持续和经历体，不得只为简短而删除。
4. 保留‘可能、可以、应当、必须、似乎、据称’等情态和证据强度。
5. ‘把’字句和‘被’字句涉及信息焦点与责任主体，不以主动句为统一目标。
6. 长定语只有在修饰关系明确时才拆分；避免产生新的歧义或悬垂修饰。
7. ‘进行、予以、实现、相关、方面’等词只在空泛且可安全替换时删改。
8. 逻辑连接词承载因果、条件、转折、递进、时间关系，不得当作赘词统一删除。
9. 技术、法律、政策和产品术语应优先遵循用户词汇表、国家标准和领域规范。
10. 同一概念保持同一用词；不要为了所谓文采轮换同义词。
11. 标点、数字、单位、全角半角和书名号按原文体例及现行规范保持一致。
12. 不判断文本是否由AI生成，只处理可观察的套话堆积、空泛强调和机械重复。

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `请把文件保存到回收站之外。` | `請把檔案儲存到資源回收筒之外。` | 不得把大陆简体词汇和字形转换为台湾繁体。 |
| `该功能面向贵单位用户。` | `这个功能给你们的人用。` | 不得无故降低公文或商务语域。 |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| 按照证据和标准判断结果是否成立 | `确认` / `验证` | `验证` | 语境要求的是基于标准的有效性判断，而非简单查看。 |
| 启动程序或命令 | `执行` / `实行` | `执行` | 技术语境中用于运行命令或程序。 |
| 减少资源消耗但结果相同 | `有效` / `高效` | `高效` | 强调资源与产出的比率。 |
| 软件缺陷再次出现 | `重复` / `回归` | `回归` | ‘回归缺陷/回归测试’是稳定的工程术语。 |
| 法规表达强制义务 | `可以` / `必须` | `必须` | 语境要求义务而非许可或能力。 |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
