# Source and evidence policy — 简体中文

Access baseline: 2026-08-07.

## Decision hierarchy

1. User-provided glossary, style guide, product labels, and explicit locale/register contract
2. Binding legal, technical, or domain terminology
3. Authoritative Simplified Chinese language institutions and standards
4. Reputable contemporary corpora and edited usage in the matching region and genre
5. General dictionaries and style guides
6. Linguistic intuition

A source answers only the question within its remit. An orthographic dictionary can establish spelling but may not settle collocation, pragmatics, genre, or regional preference. A corpus can establish attested usage but not automatically prove correctness. A plain-language guide can improve accessibility but must not override legal force, technical precision, or authorial voice.

## Language-specific sources

1. [国家标准 GB/T 15834—2011《标点符号用法》](https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=22EA6D162E4110E752259661E1A0D0A8&refer=outter) — 现代汉语标点符号的官方国家标准。 Authority class: `official`.
2. [教育部语言文字应用管理司](https://www.moe.gov.cn/s78/A19/) — 国家语言文字规范、标准和应用管理资料。 Authority class: `official`.
3. [国家通用语言文字法](https://www.gov.cn/guoqing/2021-10/29/content_5647633.htm) — 规范汉字和国家通用语言文字使用的法定框架。 Authority class: `official`.
4. [国家语委语言文字规范标准](https://www.moe.gov.cn/jyb_sjzl/ziliao/A19/) — 字形、词形、标点、数字等规范资料。 Authority class: `official`.

## Cross-language design sources

1. [OpenAI — Build skills](https://developers.openai.com/codex/build-skills) — Focused workflow boundaries, concise SKILL.md, supporting references and deterministic scripts.
2. [OpenAI — Testing Agent Skills Systematically with Evals](https://developers.openai.com/blog/eval-skills) — Prompt-to-run evaluation, activation checks, artifact checks, and comparable regression scores.
3. [mEdIT: Multilingual Text Editing via Instruction Tuning](https://aclanthology.org/2024.naacl-long.56/) — Instruction-based multilingual editing across grammatical correction, simplification, and paraphrasing.
4. [Evaluating Text Style Transfer Evaluation: Are There Any Reliable Metrics?](https://aclanthology.org/2025.naacl-srw.41/) — Multidimensional evaluation: content preservation, naturalness, and task/style success.
5. [Do Large Language Models Have an English ‘Accent’?](https://arxiv.org/html/2410.15956v1) — Evidence that multilingual LLM output can retain English-centric lexical and syntactic patterns.

## Research trigger

Do not browse for routine grammar or style edits. Verify externally when the choice depends on a newly coined term, current official name, changing standard, legal wording, regulated terminology, locale-specific usage not resolved by the text, or a high-impact ambiguity. Record the source and access date when research materially determines the output.

## Uncertainty

When evidence remains insufficient, label the decision `[UNVERIFIED]` or present the viable regional alternatives. Do not present preference as a universal rule.
