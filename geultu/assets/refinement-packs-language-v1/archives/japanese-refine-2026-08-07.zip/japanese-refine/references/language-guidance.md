# 日本語 language guidance

## Variant contract

現代日本語（ja-JP）を既定とし、原文の「です・ます／だ・である」、敬語水準、媒体慣行、地域語、キャラクター口調を保持します。

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. 助詞、係り受け、主語の省略範囲、時制・相、指示語、敬語の方向を文脈単位で確認します。
2. 「です・ます」と「だ・である」を混在させず、原文の文体を維持します。
3. 漢字・ひらがな・外来語の比率は媒体と読み手に合わせ、機械的に開いたり閉じたりしません。
4. 「行う」「実施する」「こと」「もの」「という」の削減は、意味・焦点・公用文の慣行が変わらない場合に限ります。
5. 受身・使役・使役受身は、責任主体や被影響者を変えない範囲でのみ直します。
6. 長い連体修飾は係り先が一意に確定できる場合だけ分割します。
7. 接続表現の因果・条件・対比・追加・時間の関係を保持します。
8. 同じ専門語は表記ゆれを整えますが、見栄えのための同義語置換はしません。
9. 句読点・括弧・全角半角・数字表記は文書の既存方針を優先します。
10. 会話、随筆、文学の間、断片、反復、終助詞を一般的な説明文に平坦化しません。
11. 公用文・技術文書では文化庁の考え方や組織の用語集を参照し、一般文では自然な実例も確認します。
12. AI生成かどうかは判定せず、観察可能な定型句の密集や空疎な強調だけを編集信号にします。

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `本件についてご確認いただけますでしょうか。` | `これを見て。` | 依頼の敬語水準と対人関係を変えない。 |
| `ほんまに知らんねん。` | `本当に知りません。` | 意図された方言・人物語を標準語に均さない。 |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| プログラムを起動する操作 | `実施する` / `実行する` | `実行する` | 命令やプログラムを動かす技術文脈に合う。 |
| 根拠と基準に照らして正しさを確かめる | `確認する` / `検証する` | `検証する` | 単なる視認ではなく妥当性評価を表す。 |
| 不具合が再発しないことを調べるテスト | `反復テスト` / `回帰テスト` | `回帰テスト` | ソフトウェア工学の定着した用語である。 |
| 一般読者向けの操作説明 | `当該ボタンを押下する` / `このボタンを押す` | `このボタンを押す` | 法務・業務様式でない一般操作文では平易で具体的。 |
| 能力を述べる | `確認可能です` / `確認できます` | `確認できます` | 一般的な説明では自然で、能力の意味も保つ。 |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
