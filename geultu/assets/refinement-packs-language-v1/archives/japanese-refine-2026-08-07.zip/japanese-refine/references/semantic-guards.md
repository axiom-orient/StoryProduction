# Semantic-preservation guards — 日本語

Do not replace the protected Japanese expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `失敗する可能性がある` | `必ず失敗する` | 可能性と確定 |
| `有効にした場合` | `有効にしたとき` | 条件と時間・既定事実 |
| `デプロイを試みた` | `デプロイした` | 試行と完了 |
| `原因を確認できなかった` | `原因を確認した` | 否定された認識行為 |
| `一部の要求` | `すべての要求` | 数量範囲 |
| `月曜から動き続けている` | `月曜に動いた` | 継続相と完了事象 |
| `削除しないようにした` | `削除しないようになった` | 意図的措置と結果状態 |
| `そのため処理が再開した` | `その後処理が再開した` | 因果と時間順序 |
| `この数値` | `この金額` | 指示対象の種類 |
| `増加したと考えられる` | `増加した` | 推定と断定 |
| `保持する必要がある` | `必ず保持しなければならない` | 必要性の記述と強い義務 |
| `利用できる` | `利用している` | 能力・可用性と実際の使用 |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
