# Semantic-preservation guards — Русский

Do not replace the protected Russian expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `Запрос может завершиться сбоем.` | `Запрос завершится сбоем.` | возможность и уверенность |
| `Если функцию включить` | `Когда функцию включили` | условие и состоявшееся событие |
| `Агент попытался развернуть версию.` | `Агент развернул версию.` | попытка и завершение |
| `Причину не удалось подтвердить.` | `Причину подтвердили.` | отрицание |
| `Некоторые запросы` | `Все запросы` | область квантора |
| `Сервис работает с понедельника.` | `Сервис работал в понедельник.` | продолжающееся состояние и завершённое событие |
| `Защита разработана, чтобы предотвратить удаление.` | `Удаление не произошло.` | цель проектирования и наблюдаемый результат |
| `Поэтому обработка возобновилась.` | `Затем обработка возобновилась.` | причина и временная последовательность |
| `Это значение равно 12.` | `Эта цена равна 12.` | тип референта |
| `Задержка, по-видимому, растёт.` | `Задержка растёт.` | эпистемическая оговорка и утверждение |
| `Следует сохранить журнал.` | `Журнал необходимо сохранить.` | рекомендация и обязательность |
| `Адаптер может передавать результаты потоком.` | `Адаптер передаёт результаты потоком.` | способность и фактическое поведение |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
