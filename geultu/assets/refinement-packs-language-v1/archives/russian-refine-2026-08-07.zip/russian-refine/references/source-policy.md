# Source and evidence policy — Русский

Access baseline: 2026-08-07.

## Decision hierarchy

1. User-provided glossary, style guide, product labels, and explicit locale/register contract
2. Binding legal, technical, or domain terminology
3. Authoritative Russian language institutions and standards
4. Reputable contemporary corpora and edited usage in the matching region and genre
5. General dictionaries and style guides
6. Linguistic intuition

A source answers only the question within its remit. An orthographic dictionary can establish spelling but may not settle collocation, pragmatics, genre, or regional preference. A corpus can establish attested usage but not automatically prove correctness. A plain-language guide can improve accessibility but must not override legal force, technical precision, or authorial voice.

## Language-specific sources

1. [Академос — орфографический академический ресурс](https://orfo.ruslang.ru/) — Официальная кодификация письменных норм слов и устойчивых сочетаний. Authority class: `official`.
2. [Грамота.ру](https://gramota.ru/) — Словари, справочная служба, грамматика, пунктуация и вопросы употребления. Authority class: `official`.
3. [Национальный корпус русского языка](https://ruscorpora.ru/) — Корпусные примеры по жанрам, периодам и вариантам употребления. Authority class: `official`.
4. [Институт русского языка им. В. В. Виноградова РАН](https://ruslang.ru/) — Академические словари, грамматика и исследования современного русского языка. Authority class: `official`.

## Cross-language design sources

1. [OpenAI — Build skills](https://developers.openai.com/codex/build-skills) — Focused workflow boundaries, concise SKILL.md, supporting references and deterministic scripts.
2. [OpenAI — Testing Agent Skills Systematically with Evals](https://developers.openai.com/blog/eval-skills) — Prompt-to-run evaluation, activation checks, artifact checks, and comparable regression scores.
3. [mEdIT: Multilingual Text Editing via Instruction Tuning](https://aclanthology.org/2024.naacl-long.56/) — Instruction-based multilingual editing across grammatical correction, simplification, and paraphrasing.
4. [Evaluating Text Style Transfer Evaluation: Are There Any Reliable Metrics?](https://aclanthology.org/2025.naacl-srw.41/) — Multidimensional evaluation: content preservation, naturalness, and task/style success.
5. [Do Large Language Models Have an English ‘Accent’?](https://arxiv.org/html/2410.15956v1) — Evidence that multilingual LLM output can retain English-centric lexical and syntactic patterns.

## Research trigger

Do not browse for routine grammar or style edits. Verify externally when the choice depends on a newly coined term, current official name, changing standard, legal wording, regulated terminology, locale-specific usage not resolved by the text, or a high-impact ambiguity. Record the source and access date when research materially determines the output.

## Uncertainty

When evidence remains insufficient, label the decision `[UNVERIFIED]` or present the viable regional alternatives. Do not present preference as a universal rule.
