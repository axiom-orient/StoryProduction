# Semantic-preservation guards — हिंदी

Do not replace the protected Hindi expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `अनुरोध विफल हो सकता है।` | `अनुरोध विफल होगा।` | संभावना और निश्चितता |
| `यदि सुविधा चालू की जाए` | `जब सुविधा चालू की गई` | शर्त और घटित घटना |
| `एजेंट ने संस्करण तैनात करने की कोशिश की।` | `एजेंट ने संस्करण तैनात कर दिया।` | प्रयास और पूर्णता |
| `कारण की पुष्टि नहीं हो सकी।` | `कारण की पुष्टि हुई।` | निषेध |
| `कुछ अनुरोध` | `सभी अनुरोध` | परिमाण का दायरा |
| `सेवा सोमवार से चलती आ रही है।` | `सेवा सोमवार को चली।` | निरंतर पक्ष और पूर्ण घटना |
| `सुरक्षा हटाने से रोकने के लिए बनाई गई थी।` | `हटाना नहीं हुआ।` | डिज़ाइन का उद्देश्य और देखा गया परिणाम |
| `इसलिए प्रसंस्करण फिर शुरू हुआ।` | `उसके बाद प्रसंस्करण फिर शुरू हुआ।` | कारण और समय-क्रम |
| `यह मान 12 है।` | `यह कीमत 12 है।` | संदर्भित वस्तु का प्रकार |
| `विलंब बढ़ता हुआ लगता है।` | `विलंब बढ़ता है।` | अनुमान और कथन |
| `आपको लॉग रखना चाहिए।` | `आपके लिए लॉग रखना अनिवार्य है।` | सलाह और बाध्यता |
| `एडाप्टर परिणाम स्ट्रीम कर सकता है।` | `एडाप्टर परिणाम स्ट्रीम करता है।` | क्षमता और वास्तविक व्यवहार |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
