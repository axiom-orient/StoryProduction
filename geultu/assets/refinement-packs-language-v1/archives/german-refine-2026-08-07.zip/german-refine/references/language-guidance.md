# Deutsch language guidance

## Variant contract

Bewahren Sie die belegte Standardvariante und Hausorthografie — Deutschland, Österreich, Schweiz, Liechtenstein oder Südtirol. Ändern Sie insbesondere ß/ss, regionale Wörter und Anredeformen nicht ohne Auftrag.

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. Prüfen Sie Kasus, Rektion, Kongruenz, Verbklammer, Satzgliedbezug, Tempus und Modus im Kontext.
2. Bewahren Sie Konjunktiv, Modalverben und Modalpartikeln, wenn sie Distanz, Hörensagen, Möglichkeit, Empfehlung oder Haltung ausdrücken.
3. Lösen Sie lange Nominal- oder Kompositastrukturen nur auf, wenn die fachliche Zuordnung eindeutig bleibt.
4. Nominalstil ist kein pauschaler Fehler; ersetzen Sie ihn nur, wenn ein Verb denselben Rechts-, Fach- und Registerwert hat.
5. Aktiv und Passiv verteilen Fokus und Verantwortlichkeit unterschiedlich und sind nicht frei austauschbar.
6. Trennbare Verben, Satzklammer und Nebensatzstellung dürfen durch Kürzung nicht beschädigt werden.
7. Kausal-, Konditional-, Konzessiv-, Temporal- und Additivkonnektoren müssen ihre logische Beziehung behalten.
8. Fachbegriffe, amtliche Schreibweisen und Benutzer-Glossare haben Vorrang vor allgemeiner Stilpräferenz.
9. Verwenden Sie denselben Terminus für denselben Begriff; vermeiden Sie dekorative Synonymvariation.
10. Beachten Sie die seit 1. Juli 2024 verbindliche amtliche Rechtschreibung, soweit keine regionale oder organisatorische Ausnahme gilt.
11. Bewahren Sie literarische Stimme, Umgangssprache, Ellipsen und absichtliche Wiederholungen.
12. Treffen Sie keine Aussage über KI-Autorenschaft; bearbeiten Sie nur beobachtbare Leerformeln, Überbetonung und mechanische Wiederholung.

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `Die Datei wird anschliessend gespeichert.` | `Die Datei wird anschließend gespeichert.` | Schweizer ss-Schreibung nicht in deutsche ß-Schreibung umwandeln. |
| `Bitte senden Sie mir den Jännerbericht.` | `Bitte senden Sie mir den Januarbericht.` | Österreichischen Standardwortschatz erhalten. |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| Das Ziel wird erreicht | `effizient` / `effektiv` | `effektiv` | ‘Effektiv’ bezeichnet die Wirksamkeit; ‘effizient’ den Ressourceneinsatz. |
| Etwas wirkt nur dem Anschein nach so, ist aber nicht so | `anscheinend` / `scheinbar` | `scheinbar` | ‘Scheinbar’ markiert einen trügerischen Anschein; ‘anscheinend’ eine plausible Vermutung. |
| Technische Anleitung mit neutralem Register | `das Werkzeug benutzen` / `das Werkzeug verwenden` | `das Werkzeug verwenden` | ‘Verwenden’ ist neutral und im technischen Standarddeutsch üblich; Hausstil kann abweichen. |
| Eine Bedingung verlässlich herstellen | `gewährleisten` / `sicherstellen` | `sicherstellen` | Das Verb ist klar und direkt; ‘gewährleisten’ kann rechtlich stärker wirken. |
| Ein Programm starten | `das Programm umsetzen` / `das Programm ausführen` | `das Programm ausführen` | ‘Ausführen’ bezeichnet das Laufenlassen von Programmcode. |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
