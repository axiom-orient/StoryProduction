# Semantic-preservation guards — Deutsch

Do not replace the protected German expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `Die Anfrage kann fehlschlagen.` | `Die Anfrage wird fehlschlagen.` | Möglichkeit und Gewissheit |
| `Sofern die Funktion aktiviert wird` | `Sobald die Funktion aktiviert wird` | Bedingung und Zeitbeginn |
| `Der Agent versuchte, die Version bereitzustellen.` | `Der Agent stellte die Version bereit.` | Versuch und Abschluss |
| `Die Ursache konnte nicht bestätigt werden.` | `Die Ursache wurde bestätigt.` | Negation |
| `Einige Anfragen` | `Alle Anfragen` | Quantorenbereich |
| `Der Dienst läuft seit Montag.` | `Der Dienst lief am Montag.` | andauernder Zustand und abgeschlossenes Ereignis |
| `Die Sperre wurde entwickelt, um Löschen zu verhindern.` | `Es wurde nichts gelöscht.` | Entwurfsabsicht und beobachtetes Ergebnis |
| `Deshalb wurde die Verarbeitung fortgesetzt.` | `Danach wurde die Verarbeitung fortgesetzt.` | Kausalität und zeitliche Folge |
| `Dieser Wert beträgt 12.` | `Dieser Preis beträgt 12.` | Referententyp |
| `Die Latenz scheint zu steigen.` | `Die Latenz steigt.` | epistemische Einschränkung und Behauptung |
| `Sie sollten das Protokoll aufbewahren.` | `Sie müssen das Protokoll aufbewahren.` | Empfehlung und Pflicht |
| `Der Adapter kann Ergebnisse streamen.` | `Der Adapter streamt Ergebnisse.` | Fähigkeit und tatsächliches Verhalten |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
