# Semantic-preservation guards — English

Do not replace the protected English expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `The request may fail.` | `The request will fail.` | possibility versus prediction/certainty |
| `The reviewer did not confirm the cause.` | `The reviewer confirmed the cause.` | negation |
| `If the feature is enabled, logging starts.` | `When the feature is enabled, logging starts.` | condition versus assumed time/event |
| `Some requests are retried.` | `All requests are retried.` | quantifier scope |
| `The worker has been running since Monday.` | `The worker ran on Monday.` | continuing aspect versus completed event |
| `The guard was designed to prevent deletion.` | `Deletion happened not to occur.` | intentional design versus observed result |
| `Latency appears to increase.` | `Latency increases.` | epistemic qualification versus assertion |
| `Because the lock was released, processing resumed.` | `After the lock was released, processing resumed.` | causality versus temporal order |
| `This value is 12.` | `This price is 12.` | referent type |
| `The agent attempted to deploy the build.` | `The agent deployed the build.` | attempt versus completion |
| `You should retain the log.` | `You must retain the log.` | recommendation versus obligation |
| `The adapter can stream results.` | `The adapter streams results.` | capability versus actual behavior |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
