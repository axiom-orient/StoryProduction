# English language guidance

## Variant contract

Preserve the evidenced dialect and house style (for example, US, UK, Canadian, Australian, or international English). Use US English only when no variant is specified or evidenced, and never mix variants within one document.

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. Check articles, countability, subject–verb agreement, pronoun reference, modifier attachment, parallelism, and punctuation in context.
2. Preserve the distinct force of may, might, can, could, should, must, shall, and will; do not optimize them as interchangeable synonyms.
3. Prefer a concrete verb over a nominalization only when agency, tense, legal force, and register remain unchanged.
4. Active voice is not an absolute target. Preserve passive voice when the actor is unknown, deliberately backgrounded, or legally secondary.
5. Resolve long noun stacks only when the intended dependency is unambiguous.
6. Use common words for general audiences, but preserve domain terms when they are precise, defined, or required by a standard.
7. Avoid elegant synonym rotation. Repeated terminology is often necessary for technical precision and reference stability.
8. Preserve restrictive versus non-restrictive clauses, scope of negation, conditionals, tense, aspect, and evidential hedges.
9. Do not flatten authorial voice, dialogue, dialect, humour, or intentional fragments merely to satisfy a generic style guide.
10. Apply house terminology and a supplied glossary before general dictionaries or public style guides.
11. Use corpus evidence and authoritative documentation for disputed current terminology; do not browse for routine edits.
12. Do not claim to detect AI authorship. Treat formulaic transitions, empty intensifiers, and mechanical repetition only as observable editing signals.

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `The colour setting is saved in the centre panel.` | `The color setting is saved in the center panel.` | Preserve an established UK spelling system. |
| `The program analyzed the behavior.` | `The programme analysed the behaviour.` | Preserve an established US spelling system. |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| A countable number of defects decreased | `less errors` / `fewer errors` | `fewer errors` | ‘Errors’ is countable in standard edited English. |
| The change influences latency | `affects latency` / `effects latency` | `affects latency` | The sentence needs the verb meaning ‘influences’. |
| A general technical instruction | `utilize the command` / `use the command` | `use the command` | ‘Use’ is shorter and equally precise unless ‘utilize’ carries a special contrast. |
| Make certain that a condition holds | `assure consistency` / `ensure consistency` | `ensure consistency` | ‘Ensure’ takes the resulting condition; ‘assure’ normally takes a person. |
| Resource use versus goal achievement | `an efficient fix` / `an effective fix` | `an effective fix` | The context states that the fix solves the problem, not that it minimizes resources. |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
