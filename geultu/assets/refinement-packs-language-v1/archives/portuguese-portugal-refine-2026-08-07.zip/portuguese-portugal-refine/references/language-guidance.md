# Português europeu language guidance

## Variant contract

Use português europeu (pt-PT) e preserve tu/você/o senhor, colocação pronominal, léxico, grafias facultativas segundo a pronúncia e terminologia institucional. Não converta para português do Brasil.

A variant is not an error merely because another region uses a different form. Preserve coherent regional grammar, spelling, vocabulary, address forms, punctuation, and interface terminology unless the user explicitly requests conversion.

## Language-specific checks

1. Verifique concordância, regência, colocação pronominal, referência, tempos, aspeto e modo no contexto.
2. Preserve pode, poderia, deve, deveria, tem de e necessita de segundo a força modal real.
3. Mantenha tu, você, o senhor/a senhora e as formas verbais correspondentes segundo o texto.
4. Respeite a próclise, ênclise e mesóclise determinadas pela sintaxe e pelo registo, sem impor uma única posição.
5. Preserve o infinitivo flexionado quando marca sujeito ou estrutura informacional relevante.
6. Voz passiva, se impessoal e sujeito nulo alteram foco e responsabilidade; edite com cautela.
7. Reduza nominalizações administrativas apenas quando um verbo direto conservar precisão e formalidade.
8. Conectores causais, condicionais, concessivos, temporais e aditivos não são intercambiáveis.
9. O glossário do utilizador, a terminologia legal e os rótulos de interface prevalecem.
10. Mantenha um termo por conceito; não introduza variantes brasileiras nem sinónimos decorativos.
11. Aplique o Acordo Ortográfico e as opções admitidas de acordo com o padrão do documento e a pronúncia.
12. Não alegue detetar autoria de IA; trate apenas fórmulas vazias, ênfase sem função e repetição mecânica observável.

## Variant and register regressions

| Preserve | Do not normalize to | Reason |
|---|---|---|
| `O utilizador deve guardar o ficheiro nesta pasta.` | `O usuário deve salvar o arquivo nesta pasta.` | Não converter léxico europeu para brasileiro. |
| `Podes verificar isto amanhã.` | `Você pode verificar isso amanhã.` | Preservar tratamento e dêixis do português europeu. |

## Contextual word-choice examples

These are decision examples, not globally mandatory replacements.

| Context | Candidates | Preferred in this context | Decisive reason |
|---|---|---|---|
| A solução atinge o objetivo | `eficiente` / `eficaz` | `eficaz` | ‘Eficaz’ descreve a obtenção do resultado; ‘eficiente’ trata de recursos. |
| Ficheiro digital em interface portuguesa | `arquivo` / `ficheiro` | `ficheiro` | É a forma corrente no português europeu de tecnologia. |
| Pessoa que usa um sistema | `usuário` / `utilizador` | `utilizador` | É a forma corrente em Portugal, salvo terminologia institucional. |
| Conservar alterações numa aplicação | `salvar` / `guardar` | `guardar` | É a forma geral em interfaces portuguesas; preserve o rótulo real do produto. |
| Elemento visual do dispositivo | `tela` / `ecrã` | `ecrã` | É o termo padrão em português europeu. |

## Operational rule

A dictionary entry proves that a form exists; it does not by itself prove that the form is best in this sentence. Check syntax, collocation, referent, domain, region, register, audience, and document consistency together. When reliable sources disagree, preserve the user's documented convention or report the unresolved variation instead of inventing certainty.
