# Semantic-preservation guards — Português europeu

Do not replace the protected European Portuguese expression with the forbidden form merely because the latter appears shorter or smoother. The exact sentence need not be reproduced, but the semantic distinction is a hard constraint.

| Protected expression | Forbidden transformation | Distinction to preserve |
|---|---|---|
| `O pedido pode falhar.` | `O pedido falhará.` | possibilidade e certeza |
| `Se a funcionalidade for ativada` | `Quando a funcionalidade for ativada` | condição e evento assumido |
| `O agente tentou disponibilizar a versão.` | `O agente disponibilizou a versão.` | tentativa e conclusão |
| `Não foi possível confirmar a causa.` | `A causa foi confirmada.` | negação |
| `Alguns pedidos` | `Todos os pedidos` | escopo do quantificador |
| `O serviço funciona desde segunda-feira.` | `O serviço funcionou na segunda-feira.` | continuidade e evento concluído |
| `A proteção foi concebida para evitar a eliminação.` | `A eliminação não ocorreu.` | intenção de conceção e resultado observado |
| `Por isso, o processamento foi retomado.` | `Depois, o processamento foi retomado.` | causalidade e sequência temporal |
| `Este valor é 12.` | `Este preço é 12.` | tipo do referente |
| `A latência parece aumentar.` | `A latência aumenta.` | cautela epistémica e afirmação |
| `Deveria manter o registo.` | `Deve manter o registo.` | recomendação e obrigação |
| `O adaptador pode transmitir resultados.` | `O adaptador transmite resultados.` | capacidade e comportamento efetivo |

## Contrastive check

For every changed sentence, answer all of these for both source and result:

1. Who acts, experiences, knows, infers, or is affected?
2. Is the proposition asserted, negated, conditional, possible, recommended, required, reported, or uncertain?
3. What is the scope of negation, quantifiers, and modifiers?
4. Is the relation causal, conditional, concessive, temporal, contrastive, or additive?
5. Are tense, continuation, repetition, progress, completion, and attempted-versus-achieved status unchanged?
6. Does each demonstrative or pronoun still refer to the same kind of thing: number, price, person, place, version, event, or proposition?
7. Are observation, confirmation, inference, intention, and result state still distinguished?
8. Is locale, address form, and register unchanged?

If any answer differs, roll back the edit even when it sounds more fluent.
